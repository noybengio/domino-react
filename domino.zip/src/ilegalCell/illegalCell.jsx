import React from "react";

const illegalCell = (props) => {
    return (
        <div className={'illegal-cell'} > </div>
    );
};

export default illegalCell;